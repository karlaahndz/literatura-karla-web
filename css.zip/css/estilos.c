
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Open+Sans+Condensed:wght@300&family=Playfair+Display&display=swap');
* {
    box-sizing: border-box;
}
img {
    display: block;
    max-width: 100%;
}
body {
    background:  #212121 ;
    margin: 0;
    font-family: 'Open Sans Condensed', sans-serif;
}
h1, h2, h4, h5, h6 {
    font-family: 'Playfair Display', serif;
    letter-spacing: 1px;
}
h3{
    color: white;
    font-family: 'Playfair Display', serif;
    letter-spacing: 1px;
}
.section__titulo{
    text-align: center;
    font-size: 40px;
    color: white;
}
.contenedor{
    margin: auto;/*Para que este centrado*/
    width: 99%;/*Para que no se utilice todo el ancho de la pagina*/
}
/*-------------Estilos del header-----------*/
.header {
    height: 60px;
}
.header .contenedor {
    display: flex;
    justify-content: space-between;
}
.logo, .icon-menu{
    margin: 5px;
    color: #fff;
}
.icon-menu {
    display: block;
    width: 40px;
    height: 40px;
    font-size: 35px;
    background: #000000;
    text-align: center;
    line-height: 45px;
    border-radius: 5px;
    margin-left: auto; /*para que funcione el alineado en otros navegadores*/
    cursor: pointer; /*Para que cambie el cursor al colocarlo encima del boton*/
}
/*------------------Estilos del menu--------------- */
.nav{
    position: absolute;
    top:60px;
    left: -100%;
    width: 100%;
    transition: all 0.4s;
}
.menu{
    list-style: none;
    padding: 0;
    margin: 0;
}

.menu__link{
    display: block;
    padding: 15px;
    background: #808080;
    text-decoration: none;
    color:#FFFFFF;
    letter-spacing: 1px;
}
.menu__link:hover{ /*Para cuando le pase el mouse encima*/
    background: white;
    color: #808080;
}
.mostrar{
    left: 0;

}
.select{
    background: white;
    color: #808080;
}
/*------------------Estilos del banner--------------- */
.banner {
    margin-top: -60px;
    position: relative;
    z-index:-1000;/*Para que la imagen de fondo este detras de todo*/
    margin-bottom: 20px;
}
.banner .contenedor{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translateX(-50%) translateY(-50%);
    width: 100%;
    color: #fff;
    text-align: center;
}
.banner__txt{
    display: none;
    text-align: center;
    width: 47%;
}
.banner__titulo{
    text-align: center;
    width: 47%;
}

.bannerh__txt, .bannerp__txt{
    display: block;
    text-align: center;
    width: 100%;
    font-size: 10px;
}
.bannerh__titulo, .bannerp__titulo{
    text-align: center;
    width: 100%;
    font-size:20px;
}
/*------------------Estilos de info--------------- */
.info__columna {
    background: #000000;
    color: #fff;
    padding: 15px;
    margin-bottom: 20px;
}
/*------------------Estilos de cursos--------------- */
.cursos__columna{
    position: relative;
    margin-bottom: 30px;
}
.cursos__descripcion{
    position: absolute;
    top: 0;
    left: 0;
    color: #fff;
    background: rgba(0,0,0,0.5);
    width: 88%;
    height: 100%;
    padding: 5px;
    text-align: center;
}
.cursospoesia__descripcion{
    position: absolute;
    top: 0;
    left: 0;
    color: #fff;
    background: rgba(0,0,0,0.5);
    width: 100%;
    height: 100%;
    padding: 5px;
    text-align: center;
}


.cursos__titulo{
    font-size: 30px;
    margin: 5px 0;
}
.cursos__img{
    width: 100%;
}
/*------------------Estilos de footer--------------- */
.footer {
    background: #333;
    color: #fff;
    padding: 10px;
    text-align: center;
}
.footer .social [class^="icon-"]{/*Aplica para todas las clases que comiencen con icon-*/
    display: inline-block;
    color: #333;
    text-decoration: none;
    font-size: 30px;
    padding: 10px;
    background: white;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    line-height: 40px;
}

/*------------------Estilos resposive--------------- */
@media(min-width:480px){/* A partir de 480px vamos a empezar a hacer cambios*/
    .logo{
        font-size: 40px;
    }
    .banner__titulo{
        font-size: 30px;
        margin: 5px 0;/*5 arriba y abajo, 0 a los costados*/
    }
    .banner__txt{
        display: block;/*Para que aparezca el texto*/
        font-size: 20px;
        margin: 5px 0;
    }
    .bannerh__txt, .bannerp__txt{
        display: block;
        text-align: center;
        width: 100%;
        font-size: 10px;
    }
    .bannerh__titulo, .bannerp__titulo{
        text-align: center;
        width: 100%;
        font-size:20px;
    }
    .info, .cursos{
        display: flex;/*Para que se junten las 3 columnas*/
        justify-content: space-between;/*Para que las colum esten separadas*/
        margin-top: -50px;/*Para ponerlo por encima de la primera imagen*/
    }
    .info__columna{
        width: 33.2%;
    }
    .info__titulo{
        font-size: 30px;
        margin: 5px 0;
        text-align: center;
    }
    .section__titulo{
        width:100%;
    }
    .cursos{
        flex-wrap: wrap;/*Para el contenido que no se haya modificado en lo anterior*/
        margin-top: 0;
    }
    .cursos__columna{
        width:49.7%;
    }
    .cursos__descripcion{
        font-size:5px;
    }

    .cursos__txt{
        display: none;
    }

    .footer .social [class^="icon-"]{
        margin: 0 10px;
    }

}
@media(min-width:770px){/* En 770px hacemos otros cambios*/
    .banner__titulo{
        font-size: 45px;
    }
    .bannerh__txt, .bannerp__txt{
        display: block;
        text-align: center;
        width: 100%;
        font-size: 13px;
    }
    .bannerh__titulo, .bannerp__titulo{
        text-align: center;
        width: 100%;
        font-size:25px;
    }
    .cursos__titulo{
        font-size:35px;
    }
    .footer .social [class^="icon-"]{
        margin: 0 25px;
    }
    .cursos__descripcion{
        font-size:14px;
    }
    .cursos__txt{
        display: block;
    }

}
@media(min-width:1024px){/* Otros cambios para pantalla completa*/
    .contenedor{
        width: 1300px;/*Pra que no ocupe todo el ancho en modo escritorio*/
    }
    .section__titulo{
        font-size: 50px;
        margin: 30px 0;
    }
    .nav{
        position: static;/*Para que vuelva a su posicion original*/
        width: auto;/*Para que cada opcion del menu tenga el ancho automatico*/
    }
    .menu{
        display: flex; /*Para que no se acomoden en filas sino en columnas*/
    }
    .icon-menu{
        display: none;/*Para que no aparezca el boton*/
    }
    .menu__link{
        background: none;/*Le quitamos el color de fondo*/
        font-size: 20px;
    }
    .select{
        background: white;
    }
    .banner__titulo{
        font-size: 60px;
    }
    .banner__txt{/*Texto dentro de primera imagen*/
        font-size: 25px;
    }
    .bannerh__txt{
        display: block;
        text-align: center;
        width: 100%;
        font-size: 25px;

    }
    .bannerp__txt{
        display: block;
        text-align: center;
        width: 100%;
        font-size: 25px;

    }
    .bannerh__titulo{
        text-align: center;
        width: 100%;
        font-size:50px;
    }
    .bannerp__titulo{
        text-align: center;
        width: 100%;
        font-size:60px;
    }
    .info__titulo{
        font-size: 40px;
    }
    .info__columna{
        padding: 10px;
    }
    .cursos__descripcion{
        padding: 40px;
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
        /*align-content: center;*/
    }
    .cursos__titulo{
        font-size: 45px;
    }
    .cursos__txt{
        font-size: 20px;
        letter-spacing: 1px;
    }

}
